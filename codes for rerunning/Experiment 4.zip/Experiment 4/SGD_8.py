from cProfile import label
import numpy as np 
from generate_data import generate_data
from neural_network import nn_define_2
import tensorflow as tf 
import matplotlib.pyplot as plt 

from SB_method_1 import method_1_w0, method_1
from SB_method_2 import method_2_w0, method_2
from FVU_compute import FVU_compute


seed = 1
np.random.seed(seed)
tf.random.set_seed(seed)

x_train, y_train, x_valid, y_valid, x_test, y_test, \
    x_test_sb, y_test_sb = generate_data()

# Save training values for training error evaluation
x_train_eval = x_train
y_train_eval = y_train

# Normalize the training data
x_mean = x_train.mean(axis=0)
x_std = x_train.std(axis=0)
y_mean = y_train.mean(axis=0)
y_std = y_train.std(axis=0)
x_train = (x_train - x_mean) / x_std
y_train = (y_train - y_mean) / y_std

px_test = 1 / x_std / np.sqrt(2 * np.pi) * np.exp(-1 / 2 * (((x_test_sb) / x_std) ** 2))
px_train = 1 / x_std / np.sqrt(2 * np.pi) * np.exp(-1 / 2 * ((x_train / x_std) ** 2))
px_valid = 1 / x_std / np.sqrt(2 * np.pi) * np.exp(-1 / 2 * ((x_valid / x_std) ** 2))

batch_size = 32 ###############################
learning_rate = 0.0002 #################################
epochs = 10000

# define the neural network 
model = nn_define_2(input_dim = 1, 
                    output_dim = 1, 
                    num_layers = 1, 
                    num_nodes = 2**8, ############################
                    #activation=tf.keras.activations.relu, ####################
                    activation = tf.math.cos, 
                    kernel_initializer=tf.keras.initializers.RandomNormal(mean=0.0,stddev=1.0), ##############
                    #kernel_initializer=tf.keras.initializers.truncated_normal, 
                    bias_initializer=tf.keras.initializers.Zeros())


train_dataset = tf.data.Dataset.from_tensor_slices((x_train, y_train))
train_dataset = train_dataset.shuffle(buffer_size=1).batch(batch_size)

loss_fn=tf.keras.losses.mean_squared_error
optimizer = tf.keras.optimizers.SGD(learning_rate=learning_rate) 

def nn_predict(x): # plot 
    x = (x - x_mean) / x_std
    beta = model(x) * y_std + y_mean
    return beta.numpy()

def error_compute(y, pred):
    N = np.shape(y)[0]
    diff = pred - y
    error = (np.linalg.norm(diff, ord=2))**2 / N
    return error 
    
error_train_list = []
error_valid_list = []
error_test_list = []
FVU = []
FVU_valid = []
SB_M1 = []
SB_M2 = []

# Training step
for i in range(epochs):


    # Train the Network
    for step, (x_batch_train, y_batch_train) in enumerate(train_dataset):
        # Record the loss computations
        with tf.GradientTape() as tape:
            pred = model(x_batch_train, training=True)
            loss_value = loss_fn(y_batch_train, pred)
        # Compute and apply gradients
        model.grads = tape.gradient(loss_value, model.trainable_weights)
        optimizer.apply_gradients(zip(model.grads, model.trainable_weights))
        
    pred_train = nn_predict(x_train_eval)
    error_train = error_compute(y_train, pred_train)
    #print(error_train)
    error_train_list = np.append(error_train_list, error_train)
    
    pred_valid = nn_predict(x_valid)
    error_valid = error_compute(y_valid, pred_valid)
    error_valid_list = np.append(error_valid_list, error_valid)
    
    pred_test = nn_predict(x_test)
    error_test = error_compute(y_test, pred_test)
    error_test_list = np.append(error_test_list, error_test)
    
    # Print the training loss for every tenth epoch
    if i % 10 == 0:
        print("\nEnd of epoch  " + str(i) + ", Training error " +
                      str(error_train)) 
        print("\nEnd of epoch  " + str(i) + ", Validation error " +
                      str(error_valid))
        
    FVU = np.append(FVU, FVU_compute(y_train, pred_train))
    FVU_valid = np.append(FVU_valid, FVU_compute(y_valid, pred_valid))
    
    w0_1, var = method_1_w0(x_test_sb, y_test_sb, px_test)
    pred_test_sb = nn_predict(x_test_sb)
    SB_1 = method_1(var, w0_1, x_test_sb, y_test_sb, pred_test_sb, px_test)
    SB_M1 = np.append(SB_M1, SB_1)
    
    w0_2 = method_2_w0(x_train, y_train, 1, 2, px_train) 
    SB_2 = method_2(w0_2, x_valid, y_valid, pred_valid, px_valid)
    SB_M2 = np.append(SB_M1, SB_2)
    
error_valid_min = np.min(error_valid_list)
error_test_min = np.min(error_test_list)
error_test_end = error_test_list[-1]
    
np.savez('./sgd_1.npz', 
         x_train = x_train_eval, 
         y_train = y_train_eval, 
         x_valid = x_valid, 
         y_valid = y_valid,  
         x_test = x_test, 
         y_test = y_test, 
         x_test_sb = x_test_sb, 
         y_test_sb = y_test_sb, 
         pred_train = pred_train, 
         pre_valid = pred_valid, 
         pred_test = pred_test, 
         error_train_list = error_train_list, 
         error_valid_list = error_valid_list,
         error_test_list = error_test_list, 
         error_valid_min = error_valid_min, 
         error_test_min = error_test_min, 
         error_test_end = error_test_end, 
         FVU_valid = FVU_valid, 
         SB_M1 = SB_M1, 
         SB_M2 = SB_M2)
                      
plt.subplot(2, 2, 1)
plt.plot(x_valid, pred_valid, '*', label = 'validation')
plt.plot(x_test_sb, y_test_sb, label = 'test')
plt.xlim(-4, 4)
plt.ylim(-4, 4)
plt.title("Estimation")
plt.legend()
                      
t_vec = np.arange(0, epochs)
plt.subplot(2, 2, 2)
plt.semilogy(t_vec[2:], error_train_list[2:], label='training_error')
plt.semilogy(t_vec[2:], error_valid_list[2:], label='validation_error')
plt.semilogy(t_vec[2:], error_test_list[2:], label='test_error')
plt.title("Error")
plt.legend()

plt.subplot(2, 2, 3)
plt.plot(t_vec[1:], FVU_valid[1:])
plt.title("FVU")

plt.subplot(2, 2, 4)
plt.plot(t_vec[1:], SB_M1[1:], color='blue', label="Method 1")
plt.plot(t_vec[1:], SB_M2[2:], color='red', label="Method 2")
plt.title("Spetral Bias")
plt.legend()

plt.tight_layout()
plt.savefig('./sgd_1.jpg')
plt.show()
