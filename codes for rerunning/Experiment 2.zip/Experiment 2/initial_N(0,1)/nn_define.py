import tensorflow as tf 
from tensorflow.keras.models import Model
from tensorflow.keras.layers import Dense, Input

# define model 
# Neural network 

def NN_define(input_size, m_size, output_size): 
    # encoding 
    input_img = tf.keras.Input(shape=(input_size,))


    # middle layer 
    activation = tf.math.cos 
    m_layer = Dense(m_size, activation=activation, 
                    kernel_initializer=tf.keras.initializers.RandomNormal(mean=0.0,stddev=1.0), ##############
                    bias_initializer=tf.keras.initializers.Zeros())(input_img)
    #m_layer = Dense(m_size, activation='relu')(h2_layer)

    output_img = Dense(output_size, activation='linear')(m_layer)

    model = Model(input_img, output_img)

    print(model.summary())
    
    return model 